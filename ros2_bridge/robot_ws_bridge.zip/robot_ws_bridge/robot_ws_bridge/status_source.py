"""Источники статусов робота.

В MVP статусы мокируются (см. `MockStatusSource`). Для подключения реальных
источников нужно реализовать `RosStatusSource` и подписки на выбранные топики.
"""

from __future__ import annotations

import time
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class StatusMessage:
    """Сообщение статуса, которое будет отправлено в WS."""

    topic: str
    ts: int
    data: dict[str, Any]


class StatusSource(ABC):
    """Абстракция источника статусов робота."""

    @abstractmethod
    def get_snapshot(self) -> dict[str, Any]:
        """Возвращает мгновенный снимок состояния.

        Returns:
            Объект `data` для сообщения `state_snapshot`.
        """

    @abstractmethod
    def poll(self) -> list[StatusMessage]:
        """Возвращает список событий статуса, накопленных с прошлого вызова.

        Returns:
            Список сообщений статуса.
        """


class MockStatusSource(StatusSource):
    """Мок-источник статусов для демонстрации интеграции."""

    def __init__(self) -> None:
        """Создаёт мок-источник со стартовыми значениями."""
        self._battery_level = 1.0
        self._mode = "manual"
        self._last_emit_ts = 0

    def get_snapshot(self) -> dict[str, Any]:
        """Возвращает снимок состояния."""
        now_ms = int(time.time() * 1000)
        return {
            "battery": {"level": self._battery_level},
            "robot_state": {"mode": self._mode, "ts": now_ms},
        }

    def poll(self) -> list[StatusMessage]:
        """Эмулирует постепенное разряжение батареи."""
        now_ms = int(time.time() * 1000)
        if now_ms - self._last_emit_ts < 200:
            return []

        self._last_emit_ts = now_ms
        self._battery_level = max(0.0, self._battery_level - 0.001)

        return [
            StatusMessage(topic="battery", ts=now_ms, data={"level": self._battery_level}),
            StatusMessage(topic="robot_state", ts=now_ms, data={"mode": self._mode}),
        ]

