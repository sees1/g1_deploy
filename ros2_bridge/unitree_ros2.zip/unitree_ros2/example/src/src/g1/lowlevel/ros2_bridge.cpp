#include "rclcpp/rclcpp.hpp"
#include "unitree_hg/msg/low_cmd.hpp"
#include "unitree_hg/msg/low_state.hpp"
#include "sensor_msgs/msg/joint_state.hpp"
#include "sensor_msgs/msg/imu.hpp"
#include "interfaces/msg/motor_command.hpp"  // ← ЗАМЕНИТЕ interfaces

#include "common/motor_crc_hg.h"  // для get_crc()

#include <array>
#include <vector>
#include <string>

constexpr int G1_NUM_MOTOR = 29;

// Имена суставов в порядке G1JointIndex (0–28)
const std::vector<std::string> G1_JOINT_NAMES = {
    "left_hip_pitch_joint",     // 0
    "left_hip_roll_joint",      // 1
    "left_hip_yaw_joint",       // 2
    "left_knee_joint",          // 3
    "left_ankle_pitch_joint",   // 4
    "left_ankle_roll_joint",    // 5
    "right_hip_pitch_joint",    // 6
    "right_hip_roll_joint",     // 7
    "right_hip_yaw_joint",      // 8
    "right_knee_joint",         // 9
    "right_ankle_pitch_joint",  // 10
    "right_ankle_roll_joint",   // 11
    "waist_yaw_joint",          // 12
    "waist_roll_joint",         // 13
    "waist_pitch_joint",        // 14
    "left_shoulder_pitch_joint",// 15
    "left_shoulder_roll_joint", // 16
    "left_shoulder_yaw_joint",  // 17
    "left_elbow_joint",         // 18
    "left_wrist_roll_joint",    // 19
    "left_wrist_pitch_joint",   // 20
    "left_wrist_yaw_joint",     // 21
    "right_shoulder_pitch_joint",//22
    "right_shoulder_roll_joint",// 23
    "right_shoulder_yaw_joint", // 24
    "right_elbow_joint",        // 25
    "right_wrist_roll_joint",   // 26
    "right_wrist_pitch_joint",  // 27
    "right_wrist_yaw_joint"     // 28
};

class UnitreeBridge : public rclcpp::Node {
public:
    UnitreeBridge() : Node("unitree_bridge") {
        motor_cmd_sub_ = this->create_subscription<interfaces::msg::MotorCommand>(
            "g1/motor_command", 10,
            [this](const interfaces::msg::MotorCommand::SharedPtr msg) {
                on_motor_command(msg);
            });

        low_state_sub_ = this->create_subscription<unitree_hg::msg::LowState>(
            "/lowstate", 10,
            [this](const unitree_hg::msg::LowState::SharedPtr msg) {
                on_low_state(msg);
            });

        lowcmd_pub_ = this->create_publisher<unitree_hg::msg::LowCmd>("/lowcmd", 10);
        joint_state_pub_ = this->create_publisher<sensor_msgs::msg::JointState>("/joint_states", 10);
        imu_pub_ = this->create_publisher<sensor_msgs::msg::Imu>("/imu", 10);
    }

private:
    int last_mode_machine_ = 0;
    int last_mode_pr_ = 0;

    void on_motor_command(const interfaces::msg::MotorCommand::SharedPtr msg) {
        if (msg->motors.size() != static_cast<size_t>(G1_NUM_MOTOR)) {
            RCLCPP_ERROR(this->get_logger(), "Expected %d motors, got %zu", G1_NUM_MOTOR, msg->motors.size());
            return;
        }

        unitree_hg::msg::LowCmd low_cmd;
        low_cmd.mode_machine = last_mode_machine_;
        low_cmd.mode_pr = last_mode_pr_;

        for (int i = 0; i < G1_NUM_MOTOR; ++i) {
            const auto& cmd = msg->motors[i];
            auto& motor = low_cmd.motor_cmd[i];
            
            // Проверка ID (опционально)
            // if (static_cast<int>(cmd.id) != i) {
            //     RCLCPP_WARN_THROTTLE(this->get_logger(), *this->get_clock(), 1000,
            //         "Motor ID mismatch at index %d: expected %d, got %u", i, i, cmd.id);
            // }

            motor.mode = 1;  // enable
            motor.q = static_cast<float>(cmd.position);
            motor.dq = static_cast<float>(cmd.velocity);
            motor.tau = static_cast<float>(cmd.torque);
            motor.kp = static_cast<float>(cmd.stiffness);
            motor.kd = static_cast<float>(cmd.damping);
        }

        get_crc(low_cmd);  // обязательно для Unitree!
        lowcmd_pub_->publish(low_cmd);
    }

    void on_low_state(const unitree_hg::msg::LowState::SharedPtr msg) {
        last_mode_machine_ = msg->mode_machine;
        last_mode_pr_ = msg->mode_pr;
    	
        // JointState
        sensor_msgs::msg::JointState js;
        js.header.stamp = this->now();
        js.name = G1_JOINT_NAMES;
        js.position.resize(G1_NUM_MOTOR);
        js.velocity.resize(G1_NUM_MOTOR);
        js.effort.resize(G1_NUM_MOTOR);

        for (int i = 0; i < G1_NUM_MOTOR; ++i) {
            js.position[i] = msg->motor_state[i].q;
            js.velocity[i] = msg->motor_state[i].dq;
            js.effort[i] = msg->motor_state[i].tau_est;
        }
        joint_state_pub_->publish(js);

        // IMU
        sensor_msgs::msg::Imu imu;
        imu.header.stamp = this->now();
        imu.header.frame_id = "imu_link";

        imu.orientation.w = msg->imu_state.quaternion[0];
        imu.orientation.x = msg->imu_state.quaternion[1];
        imu.orientation.y = msg->imu_state.quaternion[2];
        imu.orientation.z = msg->imu_state.quaternion[3];

        imu.angular_velocity.x = msg->imu_state.gyroscope[0];
        imu.angular_velocity.y = msg->imu_state.gyroscope[1];
        imu.angular_velocity.z = msg->imu_state.gyroscope[2];

        imu.linear_acceleration.x = msg->imu_state.accelerometer[0];
        imu.linear_acceleration.y = msg->imu_state.accelerometer[1];
        imu.linear_acceleration.z = msg->imu_state.accelerometer[2];

        // Ковариации неизвестны
        imu.orientation_covariance.fill(-1);
        imu.angular_velocity_covariance.fill(-1);
        imu.linear_acceleration_covariance.fill(-1);

        imu_pub_->publish(imu);
    }

    rclcpp::Subscription<interfaces::msg::MotorCommand>::SharedPtr motor_cmd_sub_;
    rclcpp::Subscription<unitree_hg::msg::LowState>::SharedPtr low_state_sub_;
    rclcpp::Publisher<unitree_hg::msg::LowCmd>::SharedPtr lowcmd_pub_;
    rclcpp::Publisher<sensor_msgs::msg::JointState>::SharedPtr joint_state_pub_;
    rclcpp::Publisher<sensor_msgs::msg::Imu>::SharedPtr imu_pub_;
};

int main(int argc, char **argv) {
    rclcpp::init(argc, argv);
    auto node = std::make_shared<UnitreeBridge>();
    rclcpp::spin(node);
    rclcpp::shutdown();
    return 0;
}
